from django.shortcuts import get_object_or_404, render
from django.contrib.auth.models import User, Group
from rest_framework.response import Response
from rest_framework.decorators import api_view, renderer_classes
from .models import MenuItem, OrderItem, Order, Cart, Category
from .serializers import MenuItemSerializer, OrderSerializer, CartSerializer, CategorySerializer, UserSerializer, GroupSerializer
from rest_framework import status
from decimal import Decimal
from django.core.paginator import Paginator, EmptyPage
from rest_framework.permissions import IsAuthenticated, IsAdminUser
from rest_framework.decorators import permission_classes
from rest_framework import generics
from rest_framework.throttling import UserRateThrottle
from rest_framework import viewsets
from rest_framework.response import Response
# Create your views here.

class MenuItemsView(generics.ListCreateAPIView):
    queryset = MenuItem.objects.all()
    serializer_class = MenuItemSerializer
    search_fields = ['category__title']
    ordering_fields = ['price', 'inventory']

    def get_permissions(self):
        if(self.request.method=='GET'):
            return []

        return [IsAuthenticated()]
    
class OrderView(generics.ListCreateAPIView):
    queryset = Order.objects.all()
    serializer_class = OrderSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        if self.request.user.is_superuser:
            return Order.objects.all()
        elif self.request.user.groups.filter(name='Delivery Crew').exists(): 
            return Order.objects.all().filter(delivery_crew=self.request.user)  
       
    def add(self, request):
        menuitem_count = Cart.objects.all().filter(user=self.request.user).count()
        if menuitem_count == 0:
            return Response({"message:": "No item"})
        items = Cart.objects.all().filter(user=self.request.user).all()

        for item in items.values():
            orderitem = OrderItem(
                menuitem_id=item['menuitem_id'],
                price=item['price'],
                quantity=item['quantity'],
            )
            orderitem.save()
        return orderitem
    
    def get_total_price(self, user):
        total = 0
        items = Cart.objects.all().filter(user=user).all()
        for item in items.values():
            total += item['price']
        return total


class SingleMenuItemView(generics.RetrieveUpdateAPIView, generics.DestroyAPIView):
    throttle_classes = [UserRateThrottle]
    queryset = MenuItem.objects.all()
    serializer_class = MenuItemSerializer

class CartView(generics.ListCreateAPIView):
    throttle_classes = [UserRateThrottle]
    queryset = Order.objects.all()
    serializer_class = CartSerializer
    permission_classes = [IsAuthenticated]
    def get_queryset(self):
        return Order.objects.all().filter(user=self.request.user)

class DeliveryCrewView(viewsets.ViewSet):
    permission_classes = [IsAuthenticated]
    def list(self):
        users = User.objects.all().filter(groups__name='Delivery Crew')
        items = UserSerializer(users, many=True)
        return Response(items.data)

    def add(self, request):
        if self.request.user.is_superuser:
            user = get_object_or_404(User, username=request.data['username'])
            deliveryCrew = Group.objects.get(name="Delivery Crew")
            deliveryCrew.user_set.add(user)
            return Response({"message": "user was added "}, 200)
        
        elif self.request.user.groups.filter(name="Manager").exists:
            user = get_object_or_404(User, username=request.data['username'])
            deliveryCrew = Group.objects.get(name="Delivery Crew")
            deliveryCrew.user_set.add(user)
            return Response({"message": "user was added "}, 200)
        
        else:
            return Response({"message":"forbidden"}, status.HTTP_403_FORBIDDEN)

    def delete(self, request):
        if self.request.user.is_superuser:
            user = get_object_or_404(User, username=request.data['username'])
            deliveryCrew = Group.objects.get(name="Delivery Crew") 
            deliveryCrew.user_set.remove(user)
            return Response({"message": "user was removed"}, 200)
        elif self.request.user.groups.filter(name="Manager").exists:
            user = get_object_or_404(User, username=request.data['username'])
            deliveryCrew = Group.objects.get(name="Delivery Crew") 
            deliveryCrew.user_set.remove(user)
            return Response({"message": "user was removed"}, 200)
        else :   
            return Response({"message":"forbidden"}, status.HTTP_403_FORBIDDEN)
        
    
class GroupView(viewsets.ViewSet):
   
    permission_classes = [IsAdminUser]
   
    
    def list(self, request):
        if self.request.user.groups.filter(name='Managers').exists() == False:
            user = User.objects.all().filter(groups="Managers")
            manager = UserSerializer(user, many=True).data
            return Response(manager, status=status.HTTP_200_OK)

    def add(self, request):
        user = get_object_or_404(User, username=request.data['username'])
        manager = Group.objects.get(name="Managers")
        manager.user_set.add(user)
        return Response({"message": "User added"}, 200)

    def delete(self, request):
        user = get_object_or_404(User, username=request.data['username'])
        manager = Group.objects.get(name="Managers")
        manager.user_set.remove(user)
        return Response({"message": "User removed "}, 200)


class CategoriesView(generics.ListCreateAPIView):
    queryset = Category.objects.all()
    serializer_class = CategorySerializer
    
    def get_permissions(self):
        if(self.request.method=='GET'):
            return []

        return [IsAuthenticated()]
    
class SingleMenuItemView(generics.RetrieveUpdateDestroyAPIView):
    queryset = MenuItem.objects.all()
    serializer_class = MenuItemSerializer
    
    def get_permissions(self):
        if(self.request.method=='GET'):
            return []

        return [IsAuthenticated()]


class CartView(generics.ListCreateAPIView):
    queryset = Cart.objects.all()
    serializer_class = CartSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return Cart.objects.all().filter(user=self.request.user)

    def delete(self):
        Cart.objects.all().filter(user=self.request.user).delete()
        return Response("deleted")




class SingleOrderView(generics.RetrieveUpdateAPIView):
    queryset = Order.objects.all()
    serializer_class = OrderSerializer
    permission_classes = [IsAuthenticated]

    def update(self, request):
        if self.request.user.groups.count()==0: 
            return Response({"message":"forbidden"}, status.HTTP_403_FORBIDDEN)
        else: 
            return super().update(request)